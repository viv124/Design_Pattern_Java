import java.io.*;
class FileAcess{
    public static void  main(String[] a1)throws IOException
    {
        FileInterface b=new ProxyFile("ahire01.txt","admin");
       // b.get();
        System.out.println(b.read());
        //System.out.println( b.write("Hello vivek\nToday lecture Design pattern"));
       // System.out.println(b.delete());
    }
}