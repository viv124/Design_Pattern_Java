public class Department implements Dept
{
    private String info,name;
    public Department(String name)
    {
       this.name=name;
    }
    public String update(String info)
    {
        System.out.println(info);
    }
    public String getInfo()
    {
       return name+"  Department Message "+info;
    }
    public void setInfo(String info)
    {
        this.info=info;
    }
}