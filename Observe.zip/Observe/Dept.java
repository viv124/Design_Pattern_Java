public interface Dept
{
     public String update(String o);
}