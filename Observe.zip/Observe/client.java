public class client 
{
    public static void main(String[] a)
    {
          HeadDepartment mh = new Mahadev_sankul();

          Department computer = new Department("Computer science");
          Department economic = new Department("Economic");
          Department msw = new Department("MSW");
          Department Yog = new Department("Yog");
          
         mh.addObserver(computer);
         mh.addObserver(economic);
         mh.addObserver(msw);
         mh.addObserver(Yog);
         
        mh.removeObserver(Yog);

         mh.setInfo("Please fast fill exam form");
        //  System.out.println(computer.update());
        //  System.out.println(economic.update());
        //  System.out.println(msw.update());
        //  System.out.println(Yog.update());
        
    }
}