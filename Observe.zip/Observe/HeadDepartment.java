public interface HeadDepartment
{
     public void addObserver(Dept d);
     public void removeObserver(Dept d);
      public void setInfo(String info);
}