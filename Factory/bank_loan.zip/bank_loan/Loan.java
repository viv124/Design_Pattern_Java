interface Loan{

    public void setData(double p,float r,float n);
    public float loanEmi();
    public String loanType();
}