public interface Value
{
    public void setValue(String Textnum);
    public String getValue() ;
}