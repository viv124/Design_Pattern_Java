public interface IntegerNumber {
    //public void SetInt(StringA Textnum);
    public int getInt();
    
}