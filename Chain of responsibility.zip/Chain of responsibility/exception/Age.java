public class Age extends ExceptionD
{
    public void voting(int age)
    {
       if (age<18)
       {
         System.out.println("Age is 18 <Please enter age.");

       } 
       else
          e.voting(age);
    }
}