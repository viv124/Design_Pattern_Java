public class ZeroException extends ExceptionD
{
    public void voting(int age)
    {
       if (age==0)
       {
         System.out.println("Age is Not Zero ! hey please enter Proper Age..");
       } 
       else
          e.voting(age);
    }
}