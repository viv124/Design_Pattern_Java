public abstract class ExceptionD
{
   protected ExceptionD e;
   public void setNext(ExceptionD e)
   {
      this.e=e;
   }  
   public abstract void voting(int age);   

}