public class NegativeE extends ExceptionD
{
    public void voting(int age)
    {
       if (age<0)
       {
         System.out.println("Age is Negative Please enter age.");

       } 
       else
          e.voting(age);
    }
}