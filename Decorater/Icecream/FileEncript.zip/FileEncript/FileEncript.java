import java.io.*;
public class FileEncript extends FileDecorator
{
    String s = "";

    InputStream its;
    public FileEncript(InputStream its)throws IOException,FileNotFoundException
    {
        super(its);
    }

    public int read()throws IOException,FileNotFoundException
    {

        int character;
        while ((character = super.read()) != -1) {
                    s += (char)character;
        }
        return 1;
    }
   
   public String fileRead()throws IOException,FileNotFoundException{

        this.read();
        return s;
   }
}