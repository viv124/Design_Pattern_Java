interface Abstract_File
{
	public void writeData(String data);
	public String readData();
}