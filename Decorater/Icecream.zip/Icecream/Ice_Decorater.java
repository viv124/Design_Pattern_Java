public abstract class Ice_Decorater implements Icecream
{
    Icecream ic;
    public Ice_Decorater(Icecream ic)
    {
        this.ic=ic;
    }
     public  double getCost()
     {
        return ic.getCost();
     }
     public  String getDescription()
     {
        return ic.getDescription();
     }
}