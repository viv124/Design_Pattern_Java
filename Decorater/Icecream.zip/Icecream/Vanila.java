public class Vanila implements Icecream
{
    public double getCost()
    {
        return 35;
    }
    public String getDescription()
    {
        return "Vanila Icecream";
    }
}