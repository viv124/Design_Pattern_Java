public class PinatButter extends Ice_Decorater
{
    public PinatButter(Icecream ic)
    {
        super(ic);
    }
    public double getCost()
    {
        return super.getCost()+80;
    }
    public String getDescription()
    {
        return super.getDescription()+"  PinatButter";
    }
}