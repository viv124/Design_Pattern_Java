public class Chocolate extends Ice_Decorater
{
    public Chocolate(Icecream ic)
    {
        super(ic);
    }
    public double getCost()
    {
        double cost=super.getCost()+25;
        return cost;
    }
    public String getDescription()
    {
        String s=super.getDescription();
        return s+"  chocolate";
    }
    public String color()
    {
        return "color";
    }
}