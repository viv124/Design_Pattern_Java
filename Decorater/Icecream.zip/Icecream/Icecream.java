public  interface Icecream
{
    public double getCost();
    public String getDescription();
}