public interface Home_Loan
{
     public void setData(double p,float r,float n);
    public double homeLoan();
    public String disH();
}