public interface Personal_Loan
{
   public void setData(double p,float r,float n);
  public double pLoan();
  public String disP();
}