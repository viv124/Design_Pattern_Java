
public class PrintSpooler {

    private static PrintSpooler ps;
   
    private PrintSpooler() { }

    public static PrintSpooler getInstance() {
          if(ps==null)
        {
            synchronized(PrintSpooler.class)
            {
                if(ps==null)
                {
                  ps=new PrintSpooler(); //jo onj null hoy to 2 thread ek sathe n avi sake
                }
            }
            
        }
        return ps;
    }

    public String print(String p) {
            return p;
    }
}
 