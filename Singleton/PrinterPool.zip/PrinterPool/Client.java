
public class Client{

    public static void main(String[] args) {
        PrintSpooler ps1 = PrintSpooler.getInstance();
        PrintSpooler ps2 = PrintSpooler.getInstance();
        System.out.println(ps1.print("spooler1"));
        System.out.println(ps2.print("spooler2"));

        //MutiThread

         Thread t1 = new Thread(new Runnable() {
            public void run() {
                PrintSpooler ps = PrintSpooler.getInstance();
                System.out.println(ps.print("Printing 1"));
            }
        });

        // print the message in other thread
        Thread t2 = new Thread(new Runnable() {
            public void run() {
                PrintSpooler ps = PrintSpooler.getInstance();
                System.out.println(ps.print("Printing 2"));
            }
        });

        t2.start();
        t1.start();
        
    }
}