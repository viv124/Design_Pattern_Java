// class Database{
//    private static Printer pt;

//    private Printer() { 
	
//    }
// 	private static int count=0; 
//    public static Printer getInstance() {
// 	   // create object if it's not already created
//       if(pt == null) {
//          pt = new Printer();
//       }
// 	  count++;

//        // returns the singleton object
//        return pt;
//    }

//    public void getConnection() {
//        System.out.println("You are now connected to the Printer."+count);
//    }
// }

