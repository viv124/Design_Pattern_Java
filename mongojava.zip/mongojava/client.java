
import java.sql.*;
public class client{
   public static void main(String[] args)throws Exception {

       // Database d=;
        DatabaseService client1 = new DatabaseService(MysqlDb.getInstance());
        client1.Connection("localhost",3306);
      
      //Database d=FactoryDB.getInstance("mongodb");
      //client1.Connection("localhost",27017);

            
      
       //client1.dropDbm("design");
         client1.insertTData("id,name","5,'kamal'");
      //client1.dbCreate("design");      
       
       System.out.println("\n \n \n --------- Show Table Data ------ \n");
       //client1.showTData("test","finance");
       client1.showTData("ahire","GVP");
       System.out.println("\n \n ----- | list of database |-------\n \n ");
       System.out.println(client1.display());
       
      
   }
}