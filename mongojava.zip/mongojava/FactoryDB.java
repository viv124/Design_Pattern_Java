public class FactoryDB
{
     public static Database getInstance(String n)
     {
        Database d;
        switch(n)
        {
             case "mysql":
                 d=MysqlDb.getInstance();
                 break;
            case "mongodb":
                d=MongoDB.getInstance();
                break;
            default:
                 d=MysqlDb.getInstance();
        }
        return d;
     }
}  